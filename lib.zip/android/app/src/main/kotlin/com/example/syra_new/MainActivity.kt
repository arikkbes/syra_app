package com.ariksoftware.syra

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
