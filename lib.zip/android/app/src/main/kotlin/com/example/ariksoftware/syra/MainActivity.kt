package com.example.syra_new

import io.flutter.embedding.android.FlutterActivity

class MainActivity : FlutterActivity()
